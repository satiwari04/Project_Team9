﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace UBERMANAGEMENTPROJECT
{
    public partial class lbldnm : Form
    {
        SqlConnection conn;
        public lbldnm()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void lbldnm_Load(object sender, EventArgs e)
        {
            lblviewunm.Text = Users.SetValueforUsername;

            try
            {
               // string sql="select UserName from USERS where "
            }
            catch(Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
    }
}
