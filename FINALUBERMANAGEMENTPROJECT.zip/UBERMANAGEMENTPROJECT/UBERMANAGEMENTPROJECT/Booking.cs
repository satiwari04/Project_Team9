﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UBERMANAGEMENTPROJECT
{
    class Booking
    {
        public int BookingId { get; set; }
        public string Username { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public int VehicleId { get; set; }
        public float Price { get; set; }

        public override string ToString()
        {
            string myData = "";
            myData += BookingId.ToString() + "\n";
            myData += Username.ToString() + "\n";
            myData += Source.ToString() + "\n";
            myData += Destination.ToString() + "\n";
            myData += VehicleId.ToString() + "\n";
            myData += Price.ToString() + "\n";
            return myData;
        }
    }
}
