﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace UBERMANAGEMENTPROJECT
{
    public partial class BookingPage : Form
    {
        SqlConnection conn;
        public BookingPage()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
            
        }

        private void BookingPage_Load(object sender, EventArgs e)
        {
            lblusname.Text = Users.SetValueforUsername;
            panel1.Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string Vehicletype = cb_vehicetype.SelectedItem.ToString();

            try
            {
                conn.Open();
                BindData();
                string sql = String.Format("select VehicleId,Price from Vehicles where VehicleName='{0}'",Vehicletype);
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    lblidview.Text = (int.Parse(reader[0].ToString()).ToString());
                    lblprice.Text = (float.Parse(reader[1].ToString())).ToString();        
                }
                conn.Close();
            }
            catch(Exception ee)
            {
                MessageBox.Show("Its an Exception " + ee.Message);
            }
        }
        public void BindData()
        {
            string sql = "select VehicleId,VehicleName from Vehicles";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                cb_vehicetype.Items.Add(reader[0].ToString());
            }
            reader.Close();
        }

        private void btnconfirmbooking_Click(object sender, EventArgs e)
        {
            Booking bookobj = new Booking();
            bookobj.Username = lblusname.Text;
            bookobj.Source = cb_startride.Text;
            bookobj.Destination = cb_endride.Text;
            bookobj.VehicleId = int.Parse(lblidview.Text);
            bookobj.Price = float.Parse(lblprice.Text);
            try
            {
                conn.Open();
                string sql_insert = string.Format("Insert into Booking values('{0}','{1}','{2}',{3},{4})", bookobj.Username, bookobj.Source, bookobj.Destination, bookobj.VehicleId, bookobj.Price);
                SqlCommand cmd = new SqlCommand(sql_insert, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Your Booking is Successful");
                panel1.Visible = true;
                conn.Close();
                AllDataSave();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception:" + ex.Message);
            }
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            string source = cb_startride.Text;
            string destination = cb_endride.Text;
            string price = lblprice.Text;
            string sql = string.Format("select Source,Destination,price from Booking where Source='{0}'and Destination='{1}' and Price={2}",source,destination,price);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    lblsource.Text = reader[0].ToString();
                    lblend.Text = reader[1].ToString();
                    lbl_price.Text = reader[2].ToString();
                }
                conn.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show("" + ee.Message);
            }

            //Details of the ride with Driver
            Driver d = new Driver();
           // d.DriverName
            try
            {
                conn.Open();
                string sql_display = "SELECT TOP 1 * FROM Driver ORDER BY NEWID()";
                SqlCommand cmd = new SqlCommand(sql_display,conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if(reader.Read())
                {
                    lblviewdrid.Text = (reader[0].ToString());
                    lbl_drivername.Text = reader[1].ToString();
                    lblcnctno.Text = reader[2].ToString();
                }
                conn.Close();
            }
            catch(Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
            

            try
            {
                string Vehicletype = cb_vehicetype.SelectedItem.ToString();

                conn.Open();
                BindData();
                string sql1 = String.Format("select Vehicle_Number from Vehicles where VehicleName='{0}'", Vehicletype);
                SqlCommand cmd = new SqlCommand(sql1, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    lblvehnum.Text =reader[0].ToString();
                }
                conn.Close();
            }
            catch(Exception ee)
            {
                MessageBox.Show("" + ee.Message);
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            UserPage up = new UserPage();
            up.Show();
            this.Hide();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


       private void AllDataSave()
        {
            DataSavePage dsp = new DataSavePage();
            //MessageBox.Show(lblusname.Text);
            dsp.UserName = lblusname.Text;
            MessageBox.Show("Booking Details");
            dsp.DriverId= (Convert.ToInt32(lblviewdrid.Text));
            dsp.DriverName = lbl_drivername.Text;
            dsp.VehicleId = int.Parse(lblidview.Text);
            dsp.VehicleName = cb_vehicetype.Text;
            dsp.VehicleNumber = lblvehnum.Text;
            try
            {
                conn.Open();
                string sql_tableinsert = String.Format("Insert into Users_Drivers values('{0}',{1},'{2}',{3},'{4}','{5}')", dsp.UserName, dsp.DriverId, dsp.DriverName, dsp.VehicleId, dsp.VehicleName, dsp.VehicleNumber);
                SqlCommand cmd = new SqlCommand(sql_tableinsert, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successful");
            }
            catch(Exception e1)
            {
                MessageBox.Show("HI"+e1.Message);
            }
            conn.Close();
        }
    }
}
