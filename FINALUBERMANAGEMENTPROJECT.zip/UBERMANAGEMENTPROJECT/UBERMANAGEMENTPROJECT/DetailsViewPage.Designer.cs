﻿namespace UBERMANAGEMENTPROJECT
{
    partial class DetailsViewPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DetailsViewPage));
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.customerDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewNoOfCustomersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.driverDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addDriverDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewDriverDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteDriverDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vehicleDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addVehicleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteVehicleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewVehicleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgdisp = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnsrch = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btndel = new System.Windows.Forms.Button();
            this.txtdnm = new System.Windows.Forms.TextBox();
            this.txtcnctno = new System.Windows.Forms.TextBox();
            this.lblcnct = new System.Windows.Forms.Label();
            this.lbldnm = new System.Windows.Forms.Label();
            this.txtdid = new System.Windows.Forms.TextBox();
            this.driverId = new System.Windows.Forms.Label();
            this.backToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgdisp)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(35, 82);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 127);
            this.panel1.TabIndex = 6;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customerDetailsToolStripMenuItem,
            this.driverDetailsToolStripMenuItem,
            this.vehicleDetailsToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.exitToolStripMenuItem,
            this.backToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // customerDetailsToolStripMenuItem
            // 
            this.customerDetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewNoOfCustomersToolStripMenuItem});
            this.customerDetailsToolStripMenuItem.Name = "customerDetailsToolStripMenuItem";
            this.customerDetailsToolStripMenuItem.Size = new System.Drawing.Size(109, 20);
            this.customerDetailsToolStripMenuItem.Text = "Customer Details";
            // 
            // viewNoOfCustomersToolStripMenuItem
            // 
            this.viewNoOfCustomersToolStripMenuItem.Name = "viewNoOfCustomersToolStripMenuItem";
            this.viewNoOfCustomersToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.viewNoOfCustomersToolStripMenuItem.Text = "View No of Customers";
            this.viewNoOfCustomersToolStripMenuItem.Click += new System.EventHandler(this.viewNoOfCustomersToolStripMenuItem_Click);
            // 
            // driverDetailsToolStripMenuItem
            // 
            this.driverDetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addDriverDetailsToolStripMenuItem,
            this.viewDriverDetailsToolStripMenuItem,
            this.deleteDriverDetailsToolStripMenuItem});
            this.driverDetailsToolStripMenuItem.Name = "driverDetailsToolStripMenuItem";
            this.driverDetailsToolStripMenuItem.Size = new System.Drawing.Size(88, 20);
            this.driverDetailsToolStripMenuItem.Text = "Driver Details";
            // 
            // addDriverDetailsToolStripMenuItem
            // 
            this.addDriverDetailsToolStripMenuItem.Name = "addDriverDetailsToolStripMenuItem";
            this.addDriverDetailsToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.addDriverDetailsToolStripMenuItem.Text = "Add Driver Details";
            this.addDriverDetailsToolStripMenuItem.Click += new System.EventHandler(this.addDriverDetailsToolStripMenuItem_Click);
            // 
            // viewDriverDetailsToolStripMenuItem
            // 
            this.viewDriverDetailsToolStripMenuItem.Name = "viewDriverDetailsToolStripMenuItem";
            this.viewDriverDetailsToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.viewDriverDetailsToolStripMenuItem.Text = "View Driver Details";
            this.viewDriverDetailsToolStripMenuItem.Click += new System.EventHandler(this.viewDriverDetailsToolStripMenuItem_Click);
            // 
            // deleteDriverDetailsToolStripMenuItem
            // 
            this.deleteDriverDetailsToolStripMenuItem.Name = "deleteDriverDetailsToolStripMenuItem";
            this.deleteDriverDetailsToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.deleteDriverDetailsToolStripMenuItem.Text = "Delete Driver Details";
            this.deleteDriverDetailsToolStripMenuItem.Click += new System.EventHandler(this.deleteDriverDetailsToolStripMenuItem_Click);
            // 
            // vehicleDetailsToolStripMenuItem
            // 
            this.vehicleDetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addVehicleToolStripMenuItem,
            this.deleteVehicleToolStripMenuItem,
            this.viewVehicleToolStripMenuItem});
            this.vehicleDetailsToolStripMenuItem.Name = "vehicleDetailsToolStripMenuItem";
            this.vehicleDetailsToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.vehicleDetailsToolStripMenuItem.Text = "Vehicle Details";
            // 
            // addVehicleToolStripMenuItem
            // 
            this.addVehicleToolStripMenuItem.Name = "addVehicleToolStripMenuItem";
            this.addVehicleToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.addVehicleToolStripMenuItem.Text = "Add Vehicle";
            this.addVehicleToolStripMenuItem.Click += new System.EventHandler(this.addVehicleToolStripMenuItem_Click);
            // 
            // deleteVehicleToolStripMenuItem
            // 
            this.deleteVehicleToolStripMenuItem.Name = "deleteVehicleToolStripMenuItem";
            this.deleteVehicleToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.deleteVehicleToolStripMenuItem.Text = "Delete Vehicle";
            // 
            // viewVehicleToolStripMenuItem
            // 
            this.viewVehicleToolStripMenuItem.Name = "viewVehicleToolStripMenuItem";
            this.viewVehicleToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.viewVehicleToolStripMenuItem.Text = "View Vehicle";
            this.viewVehicleToolStripMenuItem.Click += new System.EventHandler(this.viewVehicleToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.reportsToolStripMenuItem.Text = "Reports";
            this.reportsToolStripMenuItem.Click += new System.EventHandler(this.reportsToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // dgdisp
            // 
            this.dgdisp.BackgroundColor = System.Drawing.Color.White;
            this.dgdisp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgdisp.Location = new System.Drawing.Point(283, 82);
            this.dgdisp.Name = "dgdisp";
            this.dgdisp.Size = new System.Drawing.Size(403, 212);
            this.dgdisp.TabIndex = 9;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnsrch);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.txtdid);
            this.panel2.Controls.Add(this.driverId);
            this.panel2.Location = new System.Drawing.Point(389, 95);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(372, 236);
            this.panel2.TabIndex = 10;
            // 
            // btnsrch
            // 
            this.btnsrch.Location = new System.Drawing.Point(255, 18);
            this.btnsrch.Name = "btnsrch";
            this.btnsrch.Size = new System.Drawing.Size(75, 23);
            this.btnsrch.TabIndex = 15;
            this.btnsrch.Text = "SEARCH";
            this.btnsrch.UseVisualStyleBackColor = true;
            this.btnsrch.Click += new System.EventHandler(this.btnsrch_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btndel);
            this.panel3.Controls.Add(this.txtdnm);
            this.panel3.Controls.Add(this.txtcnctno);
            this.panel3.Controls.Add(this.lblcnct);
            this.panel3.Controls.Add(this.lbldnm);
            this.panel3.Location = new System.Drawing.Point(25, 79);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(305, 154);
            this.panel3.TabIndex = 14;
            // 
            // btndel
            // 
            this.btndel.Location = new System.Drawing.Point(135, 115);
            this.btndel.Name = "btndel";
            this.btndel.Size = new System.Drawing.Size(75, 23);
            this.btndel.TabIndex = 22;
            this.btndel.Text = "DELETE";
            this.btndel.UseVisualStyleBackColor = true;
            this.btndel.Click += new System.EventHandler(this.btndel_Click);
            // 
            // txtdnm
            // 
            this.txtdnm.Location = new System.Drawing.Point(135, 25);
            this.txtdnm.Name = "txtdnm";
            this.txtdnm.Size = new System.Drawing.Size(115, 20);
            this.txtdnm.TabIndex = 21;
            // 
            // txtcnctno
            // 
            this.txtcnctno.Location = new System.Drawing.Point(135, 75);
            this.txtcnctno.Name = "txtcnctno";
            this.txtcnctno.Size = new System.Drawing.Size(115, 20);
            this.txtcnctno.TabIndex = 20;
            // 
            // lblcnct
            // 
            this.lblcnct.AutoSize = true;
            this.lblcnct.BackColor = System.Drawing.Color.Transparent;
            this.lblcnct.Location = new System.Drawing.Point(19, 78);
            this.lblcnct.Name = "lblcnct";
            this.lblcnct.Size = new System.Drawing.Size(84, 13);
            this.lblcnct.TabIndex = 19;
            this.lblcnct.Text = "Contact Number";
            // 
            // lbldnm
            // 
            this.lbldnm.AutoSize = true;
            this.lbldnm.BackColor = System.Drawing.Color.Transparent;
            this.lbldnm.Location = new System.Drawing.Point(19, 28);
            this.lbldnm.Name = "lbldnm";
            this.lbldnm.Size = new System.Drawing.Size(66, 13);
            this.lbldnm.TabIndex = 18;
            this.lbldnm.Text = "Driver Name";
            // 
            // txtdid
            // 
            this.txtdid.Location = new System.Drawing.Point(132, 18);
            this.txtdid.Name = "txtdid";
            this.txtdid.Size = new System.Drawing.Size(100, 20);
            this.txtdid.TabIndex = 13;
            // 
            // driverId
            // 
            this.driverId.AutoSize = true;
            this.driverId.BackColor = System.Drawing.Color.Transparent;
            this.driverId.Location = new System.Drawing.Point(44, 21);
            this.driverId.Name = "driverId";
            this.driverId.Size = new System.Drawing.Size(49, 13);
            this.driverId.TabIndex = 12;
            this.driverId.Text = "Driver ID";
            // 
            // backToolStripMenuItem
            // 
            this.backToolStripMenuItem.Name = "backToolStripMenuItem";
            this.backToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.backToolStripMenuItem.Text = "Back";
            this.backToolStripMenuItem.Click += new System.EventHandler(this.backToolStripMenuItem_Click);
            // 
            // DetailsViewPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dgdisp);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "DetailsViewPage";
            this.Text = "DetailsViewPage";
            this.Load += new System.EventHandler(this.DetailsViewPage_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgdisp)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem customerDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewNoOfCustomersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem driverDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addDriverDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewDriverDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteDriverDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vehicleDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addVehicleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteVehicleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewVehicleToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgdisp;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtdid;
        private System.Windows.Forms.Label driverId;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtdnm;
        private System.Windows.Forms.TextBox txtcnctno;
        private System.Windows.Forms.Label lblcnct;
        private System.Windows.Forms.Label lbldnm;
        private System.Windows.Forms.Button btnsrch;
        private System.Windows.Forms.Button btndel;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backToolStripMenuItem;
    }
}