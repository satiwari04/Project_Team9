﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UBERMANAGEMENTPROJECT
{
    class Vehicle
    {
        public int VehicleId { get; set; }
        public string VehicleName { get; set; }
        public float Price { get; set; }
        public string VehicleNumber { get; set; }


        public override string ToString()
        {
            string myData="";
            myData += VehicleId.ToString() + "\n";
            myData += VehicleName.ToString() + "\n";
            myData += Price.ToString() + "\n";
            myData += VehicleNumber.ToString() + "\n";
            return myData;
        }
    }
}
