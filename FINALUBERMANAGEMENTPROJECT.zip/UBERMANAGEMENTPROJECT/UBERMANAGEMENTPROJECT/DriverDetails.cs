﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace UBERMANAGEMENTPROJECT
{
    public partial class DriverDetails : Form
    {
        SqlConnection conn;
        public DriverDetails()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminPage ap = new AdminPage();
            ap.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Driver d = new Driver();
            d.DriverName = txtdrivername.Text;
            d.ContactNumber = long.Parse(txtcnctno.Text);
            try
            {
                string sql = string.Format("insert into Driver values('{0}',{1})", d.DriverName, d.ContactNumber);
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Insertion Successful");
            }
            catch(Exception e1)
            {
                MessageBox.Show(" Exception:"+e1.Message);
            }
        }

        private void DriverDetails_Load(object sender, EventArgs e)
        {

        }
    }
}
