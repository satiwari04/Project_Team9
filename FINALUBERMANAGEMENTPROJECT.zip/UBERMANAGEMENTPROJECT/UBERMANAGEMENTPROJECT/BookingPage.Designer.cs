﻿namespace UBERMANAGEMENTPROJECT
{
    partial class BookingPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblvehicle = new System.Windows.Forms.Label();
            this.lblusname = new System.Windows.Forms.Label();
            this.cb_vehicetype = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblprice = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cb_startride = new System.Windows.Forms.ComboBox();
            this.cb_endride = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cb_location = new System.Windows.Forms.ComboBox();
            this.btnconfirmbooking = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblviewdrid = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            this.lblvehnum = new System.Windows.Forms.Label();
            this.lblvehn = new System.Windows.Forms.Label();
            this.lbl_price = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblcnctno = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_drivername = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblend = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblsource = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblbookingid = new System.Windows.Forms.Label();
            this.lblidview = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnback = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.lbldt = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Minion Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "WELCOME!!!";
            // 
            // lblvehicle
            // 
            this.lblvehicle.AutoSize = true;
            this.lblvehicle.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvehicle.Location = new System.Drawing.Point(22, 118);
            this.lblvehicle.Name = "lblvehicle";
            this.lblvehicle.Size = new System.Drawing.Size(89, 18);
            this.lblvehicle.TabIndex = 1;
            this.lblvehicle.Text = "Select Ride On";
            // 
            // lblusname
            // 
            this.lblusname.AutoSize = true;
            this.lblusname.Font = new System.Drawing.Font("Minion Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusname.Location = new System.Drawing.Point(152, 9);
            this.lblusname.Name = "lblusname";
            this.lblusname.Size = new System.Drawing.Size(82, 22);
            this.lblusname.TabIndex = 2;
            this.lblusname.Text = "User Name";
            // 
            // cb_vehicetype
            // 
            this.cb_vehicetype.FormattingEnabled = true;
            this.cb_vehicetype.Items.AddRange(new object[] {
            "Auto",
            "Mini Car",
            "Micro Car",
            "Share Car"});
            this.cb_vehicetype.Location = new System.Drawing.Point(156, 115);
            this.cb_vehicetype.Name = "cb_vehicetype";
            this.cb_vehicetype.Size = new System.Drawing.Size(121, 21);
            this.cb_vehicetype.TabIndex = 3;
            this.cb_vehicetype.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "Price";
            // 
            // lblprice
            // 
            this.lblprice.AutoSize = true;
            this.lblprice.Location = new System.Drawing.Point(153, 193);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(13, 13);
            this.lblprice.TabIndex = 5;
            this.lblprice.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(411, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "Start Ride";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(414, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 18);
            this.label4.TabIndex = 7;
            this.label4.Text = "End Ride";
            // 
            // cb_startride
            // 
            this.cb_startride.FormattingEnabled = true;
            this.cb_startride.Items.AddRange(new object[] {
            "Swargate",
            "Hadapsar",
            "Shivajinagar",
            "Pune Station",
            "FC ROAD",
            "MG ROAD",
            "ABC CHOWK"});
            this.cb_startride.Location = new System.Drawing.Point(505, 115);
            this.cb_startride.Name = "cb_startride";
            this.cb_startride.Size = new System.Drawing.Size(200, 21);
            this.cb_startride.TabIndex = 8;
            // 
            // cb_endride
            // 
            this.cb_endride.FormattingEnabled = true;
            this.cb_endride.Items.AddRange(new object[] {
            "Swargate",
            "Hadapsar",
            "Pune Station",
            "Shivajinagar",
            "FC ROAD",
            "MG ROAD",
            "ABC CHOWK"});
            this.cb_endride.Location = new System.Drawing.Point(502, 177);
            this.cb_endride.Name = "cb_endride";
            this.cb_endride.Size = new System.Drawing.Size(200, 21);
            this.cb_endride.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Minion Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(410, 55);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 22);
            this.label5.TabIndex = 10;
            this.label5.Text = "Select Location";
            // 
            // cb_location
            // 
            this.cb_location.FormattingEnabled = true;
            this.cb_location.Items.AddRange(new object[] {
            "PUNE",
            "MUMBAI",
            "BANGLORE",
            "CHENNAI"});
            this.cb_location.Location = new System.Drawing.Point(549, 55);
            this.cb_location.Name = "cb_location";
            this.cb_location.Size = new System.Drawing.Size(200, 21);
            this.cb_location.TabIndex = 11;
            // 
            // btnconfirmbooking
            // 
            this.btnconfirmbooking.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnconfirmbooking.Location = new System.Drawing.Point(22, 258);
            this.btnconfirmbooking.Name = "btnconfirmbooking";
            this.btnconfirmbooking.Size = new System.Drawing.Size(144, 36);
            this.btnconfirmbooking.TabIndex = 12;
            this.btnconfirmbooking.Text = "Confirm Booking";
            this.btnconfirmbooking.UseVisualStyleBackColor = true;
            this.btnconfirmbooking.Click += new System.EventHandler(this.btnconfirmbooking_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.lblviewdrid);
            this.panel1.Controls.Add(this.lblid);
            this.panel1.Controls.Add(this.lblvehnum);
            this.panel1.Controls.Add(this.lblvehn);
            this.panel1.Controls.Add(this.lbl_price);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.lblcnctno);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.lbl_drivername);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.lblend);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.lblsource);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(373, 227);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(415, 227);
            this.panel1.TabIndex = 13;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblviewdrid
            // 
            this.lblviewdrid.AutoSize = true;
            this.lblviewdrid.BackColor = System.Drawing.Color.Transparent;
            this.lblviewdrid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblviewdrid.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblviewdrid.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblviewdrid.Location = new System.Drawing.Point(129, 106);
            this.lblviewdrid.Name = "lblviewdrid";
            this.lblviewdrid.Size = new System.Drawing.Size(25, 20);
            this.lblviewdrid.TabIndex = 14;
            this.lblviewdrid.Text = "ID";
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.BackColor = System.Drawing.Color.Transparent;
            this.lblid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblid.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblid.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblid.Location = new System.Drawing.Point(18, 106);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(61, 20);
            this.lblid.TabIndex = 13;
            this.lblid.Text = "Driver Id";
            // 
            // lblvehnum
            // 
            this.lblvehnum.AutoSize = true;
            this.lblvehnum.BackColor = System.Drawing.Color.Transparent;
            this.lblvehnum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblvehnum.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblvehnum.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvehnum.Location = new System.Drawing.Point(138, 193);
            this.lblvehnum.Name = "lblvehnum";
            this.lblvehnum.Size = new System.Drawing.Size(46, 20);
            this.lblvehnum.TabIndex = 12;
            this.lblvehnum.Text = "vcnum";
            // 
            // lblvehn
            // 
            this.lblvehn.AutoSize = true;
            this.lblvehn.BackColor = System.Drawing.Color.Transparent;
            this.lblvehn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblvehn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblvehn.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvehn.Location = new System.Drawing.Point(21, 193);
            this.lblvehn.Name = "lblvehn";
            this.lblvehn.Size = new System.Drawing.Size(99, 20);
            this.lblvehn.TabIndex = 11;
            this.lblvehn.Text = "Vehicle Number";
            // 
            // lbl_price
            // 
            this.lbl_price.AutoSize = true;
            this.lbl_price.BackColor = System.Drawing.Color.Transparent;
            this.lbl_price.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_price.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbl_price.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_price.Location = new System.Drawing.Point(293, 106);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(37, 20);
            this.lbl_price.TabIndex = 10;
            this.lbl_price.Text = "price";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label15.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(207, 106);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 20);
            this.label15.TabIndex = 9;
            this.label15.Text = "PRICE";
            // 
            // lblcnctno
            // 
            this.lblcnctno.AutoSize = true;
            this.lblcnctno.BackColor = System.Drawing.Color.Transparent;
            this.lblcnctno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblcnctno.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblcnctno.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcnctno.Location = new System.Drawing.Point(324, 154);
            this.lblcnctno.Name = "lblcnctno";
            this.lblcnctno.Size = new System.Drawing.Size(45, 20);
            this.lblcnctno.TabIndex = 8;
            this.lblcnctno.Text = "cnctno";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label13.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(207, 154);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 20);
            this.label13.TabIndex = 7;
            this.label13.Text = "Driver Contact";
            // 
            // lbl_drivername
            // 
            this.lbl_drivername.AutoSize = true;
            this.lbl_drivername.BackColor = System.Drawing.Color.Transparent;
            this.lbl_drivername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_drivername.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbl_drivername.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_drivername.Location = new System.Drawing.Point(135, 154);
            this.lbl_drivername.Name = "lbl_drivername";
            this.lbl_drivername.Size = new System.Drawing.Size(40, 20);
            this.lbl_drivername.TabIndex = 6;
            this.lbl_drivername.Text = "name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label11.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(18, 154);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 20);
            this.label11.TabIndex = 5;
            this.label11.Text = "Driver Name";
            // 
            // lblend
            // 
            this.lblend.AutoSize = true;
            this.lblend.BackColor = System.Drawing.Color.Transparent;
            this.lblend.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblend.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblend.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblend.Location = new System.Drawing.Point(298, 65);
            this.lblend.Name = "lblend";
            this.lblend.Size = new System.Drawing.Size(32, 20);
            this.lblend.TabIndex = 4;
            this.lblend.Text = "End";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label9.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(207, 65);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 20);
            this.label9.TabIndex = 3;
            this.label9.Text = "END";
            // 
            // lblsource
            // 
            this.lblsource.AutoSize = true;
            this.lblsource.BackColor = System.Drawing.Color.Transparent;
            this.lblsource.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblsource.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblsource.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsource.Location = new System.Drawing.Point(111, 65);
            this.lblsource.Name = "lblsource";
            this.lblsource.Size = new System.Drawing.Size(47, 20);
            this.lblsource.TabIndex = 2;
            this.lblsource.Text = "Source";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label7.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(21, 65);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 20);
            this.label7.TabIndex = 1;
            this.label7.Text = "START";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Minion Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(32, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(281, 22);
            this.label6.TabIndex = 0;
            this.label6.Text = "User Ride is Secure with UBER RIDER!!!";
            // 
            // lblbookingid
            // 
            this.lblbookingid.AutoSize = true;
            this.lblbookingid.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbookingid.Location = new System.Drawing.Point(25, 59);
            this.lblbookingid.Name = "lblbookingid";
            this.lblbookingid.Size = new System.Drawing.Size(66, 18);
            this.lblbookingid.TabIndex = 14;
            this.lblbookingid.Text = "Vehicle ID";
            // 
            // lblidview
            // 
            this.lblidview.AutoSize = true;
            this.lblidview.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblidview.Location = new System.Drawing.Point(153, 59);
            this.lblidview.Name = "lblidview";
            this.lblidview.Size = new System.Drawing.Size(23, 18);
            this.lblidview.TabIndex = 15;
            this.lblidview.Text = "ID";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(547, 12);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // btnback
            // 
            this.btnback.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(22, 333);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(144, 36);
            this.btnback.TabIndex = 17;
            this.btnback.Text = "BACK";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnexit
            // 
            this.btnexit.Font = new System.Drawing.Font("Minion Pro", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(25, 404);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(144, 36);
            this.btnexit.TabIndex = 18;
            this.btnexit.Text = "EXIT";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // lbldt
            // 
            this.lbldt.AutoSize = true;
            this.lbldt.Font = new System.Drawing.Font("Minion Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldt.Location = new System.Drawing.Point(405, 13);
            this.lbldt.Name = "lbldt";
            this.lbldt.Size = new System.Drawing.Size(41, 22);
            this.lbldt.TabIndex = 19;
            this.lbldt.Text = "Date";
            // 
            // BookingPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 466);
            this.Controls.Add(this.lbldt);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lblidview);
            this.Controls.Add(this.lblbookingid);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnconfirmbooking);
            this.Controls.Add(this.cb_location);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cb_endride);
            this.Controls.Add(this.cb_startride);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblprice);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cb_vehicetype);
            this.Controls.Add(this.lblusname);
            this.Controls.Add(this.lblvehicle);
            this.Controls.Add(this.label1);
            this.Name = "BookingPage";
            this.Text = "BookingPage";
            this.Load += new System.EventHandler(this.BookingPage_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblvehicle;
        private System.Windows.Forms.Label lblusname;
        private System.Windows.Forms.ComboBox cb_vehicetype;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cb_startride;
        private System.Windows.Forms.ComboBox cb_endride;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cb_location;
        private System.Windows.Forms.Button btnconfirmbooking;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblbookingid;
        private System.Windows.Forms.Label lblidview;
        private System.Windows.Forms.Label lbl_price;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblcnctno;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl_drivername;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblend;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblsource;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lblvehnum;
        private System.Windows.Forms.Label lblvehn;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label lbldt;
        private System.Windows.Forms.Label lblviewdrid;
        private System.Windows.Forms.Label lblid;
    }
}