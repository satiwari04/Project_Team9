﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UBERMANAGEMENTPROJECT
{
    class DataSavePage
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public int DriverId { get; set; }
        public string DriverName { get; set; }
        public int VehicleId { get; set; }
        public string VehicleName { get; set; }
        public string VehicleNumber { get; set; }
       // public DateTime date { get; }

        public override string ToString()
        {
            string myData = "";
            myData += Id.ToString() + "\n";
            myData += UserName.ToString() + "\n";
            myData += DriverId.ToString() + "\n";
            myData += DriverName.ToString() + "\n";
            myData += VehicleId.ToString() + "\n";
            myData += VehicleName.ToString() + "\n";
            myData += VehicleNumber.ToString() + "\n";
           // myData += date.ToString() + "\n";
            return myData;
        }
    }
}
