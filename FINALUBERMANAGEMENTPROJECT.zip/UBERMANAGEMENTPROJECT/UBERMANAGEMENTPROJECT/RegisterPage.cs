﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UBERMANAGEMENTPROJECT
{
    public partial class RegisterPage : Form
    {
        SqlConnection conn;
        public RegisterPage()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // string Username, Password, ConfirmPassword;

            User_login user = new User_login();
            user.Username = txtusername.Text;
            user.Password = txtpassword.Text;
            user.ConfirmPassword = txtconpass.Text;
            string sql=string.Format("insert into USERS values('{0}','{1}')",user.Username,user.Password);
            try
            {
                if (user.Password.Equals(user.ConfirmPassword))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Registration Successful!!!...Thank You For Registration!!!");
                }
                else
                {
                    MessageBox.Show("Password donot match");
                    txtusername.Text = "";
                    txtpassword.Text = "";
                    txtconpass.Text = "";
                }
            }
            catch(Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Users u = new Users();
            u.Show();
        }

        private void RegisterPage_Load(object sender, EventArgs e)
        {

        }
    }
}
