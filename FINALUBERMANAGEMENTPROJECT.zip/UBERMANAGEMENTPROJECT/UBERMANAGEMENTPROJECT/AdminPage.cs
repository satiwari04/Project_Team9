﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace UBERMANAGEMENTPROJECT
{
    public partial class AdminPage : Form
    {
        SqlConnection conn;
        public AdminPage()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Username, Password;
            Username = txtusername.Text;
            Password = txtpassword.Text;

            try
            {
                conn.Open();
                String sql = "select * from Admin where Username=@name and Password=@pass";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlParameter parameter = new SqlParameter("@name", Username);
                SqlParameter parameter1 = new SqlParameter("@pass", Password);
                cmd.Parameters.Add(parameter);
                cmd.Parameters.Add(parameter1);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    User_login user = new User_login();
                    user.Username = reader[0].ToString();
                    user.Password = reader[1].ToString();
                    MessageBox.Show("Admin Login Successful");
                    DetailsViewPage dvp = new DetailsViewPage();
                    dvp.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Sorry You are not the Admin");
                    txtusername.Text = "";
                    txtpassword.Text = "";

                }
                conn.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show("" + ee.Message);
            }
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Dashboard db = new Dashboard();
            db.Show();
            this.Hide();
        }
    }
}
