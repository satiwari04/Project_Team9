﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace UBERMANAGEMENTPROJECT
{
    public partial class RideHistory : Form
    {
        SqlConnection conn;
        public RideHistory()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void RideHistory_Load(object sender, EventArgs e)
        {
            label2.Text = Users.SetValueforUsername;

            List<DataSavePage> details = new List<DataSavePage>();
            try
            {
                string sql = "select Username from Users_Drivers where Username="+(label2.Text);
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    DataSavePage d = new DataSavePage();
                    d.Id = int.Parse(reader[0].ToString());
                    d.UserName = reader[1].ToString();
                   // d.DriverId = Convert.ToInt32(reader[2].ToString());
                    d.DriverName = reader[2].ToString();
                    d.VehicleName = reader[3].ToString();

                    details.Add(d);

                }

                dgView.DataSource = details;
                conn.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }
    }
}
