﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UBERMANAGEMENTPROJECT
{
    
    public partial class AddVehicles : Form
    {
        SqlConnection conn;

        public AddVehicles()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void AddVehicles_Load(object sender, EventArgs e)
        {
            Vehicle v = new Vehicle();
            v.VehicleName = txtvehname.Text;
            MessageBox.Show(txtprice.Text);
            v.Price = (float.Parse(txtprice.Text));
            v.VehicleNumber = txtvehnum.Text;
            try
            {
                string sql = string.Format("insert into Vehicles values('{0}',{1},'{2}')", v.VehicleName,v.Price,v.VehicleNumber);
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Insertion Successful");
            }
            catch (Exception e1)
            {
                MessageBox.Show(" Exception:" + e1.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminPage ap = new AdminPage();
            ap.Show();
            this.Hide();
        }
    }
}
