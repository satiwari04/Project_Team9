﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace UBERMANAGEMENTPROJECT
{
    public partial class DetailsViewPage : Form
    {
        SqlConnection conn;
        public DetailsViewPage()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void DetailsViewPage_Load(object sender, EventArgs e)
        {
            dgdisp.Visible = false;
            panel2.Visible = false;
        }

        private void viewNoOfCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            conn.Open();
            string sql = "select count(*) from USERS";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                User_login user = new User_login();

                MessageBox.Show(reader[0].ToString());
            }
            conn.Close();

        }

        private void addDriverDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DriverDetails dd = new DriverDetails();
            dd.Show();
            this.Hide();
        }

        private void viewDriverDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dgdisp.Visible = true;
            panel2.Visible = false;
            List<Driver> driverDetails = new List<Driver>();
            try
            {
                string sql = "select * from Driver";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Driver driver = new Driver();
                    driver.DriverId = int.Parse(reader[0].ToString());
                    driver.DriverName = reader[1].ToString();
                    driver.ContactNumber = Convert.ToInt64(reader[2].ToString());

                    driverDetails.Add(driver);

                }

                dgdisp.DataSource = driverDetails;
                conn.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }

        private void btnsrch_Click(object sender, EventArgs e)
        {
            
            dgdisp.Visible = false;
            string driverid = txtdid.Text;
            string sql = "select * from Driver where DriverId=" + driverid;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    Driver driver = new Driver();
                    driver.DriverId = int.Parse(reader[0].ToString());
                    driver.DriverName = reader[1].ToString();
                    driver.ContactNumber = Convert.ToInt64(reader[2].ToString());
                    updateMe(driver);
                }
                else
                {
                    MessageBox.Show("Driver ID doesnot Exsits");
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void updateMe(Driver driver)
        {
            panel3.Visible = false;
            txtdnm.Text = driver.DriverName;
            txtcnctno.Text = Convert.ToInt64(driver.ContactNumber).ToString();
            panel3.Visible = true;
        }


    private void deleteDriverDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
                panel2.Visible = true;
                
        }

        private void btndel_Click(object sender, EventArgs e)
        {
    
            try
            {
                string driverid = txtdid.Text;
                string sql1 = "Delete from Driver where DriverId=" + driverid;

                conn.Open();
                SqlCommand cmd = new SqlCommand(sql1 , conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully!!!");
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void viewVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dgdisp.Visible = true;
            panel2.Visible = false;
            List<Vehicle> vehicleDetails = new List<Vehicle>();
            try
            {
                string sql = "select * from Vehicles";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Vehicle v = new Vehicle();
                    v.VehicleId = int.Parse(reader[0].ToString());
                    v.VehicleName = reader[1].ToString();
                    v.Price = int.Parse(reader[2].ToString());
                    v.VehicleNumber = reader[3].ToString();

                    vehicleDetails.Add(v);

                }

                dgdisp.DataSource = vehicleDetails;
                conn.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dgdisp.Visible = true;
            panel2.Visible = false;
            List<DataSavePage> details = new List<DataSavePage>();
            try
            {
                string sql = "select * from Users_Drivers";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    DataSavePage d = new DataSavePage();
                    d.Id=int.Parse(reader[0].ToString());
                    d.UserName = reader[1].ToString();
                    d.DriverId = int.Parse(reader[2].ToString());
                    d.DriverName = reader[3].ToString();
                    d.VehicleId = Convert.ToInt32(reader[4].ToString());
                    d.VehicleName = reader[5].ToString();
                    d.VehicleNumber = reader[6].ToString();

                    details.Add(d);

                }

                dgdisp.DataSource = details;
                conn.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }

        private void backToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are Logged Out");
            AdminPage ap = new AdminPage();
            ap.Show();
            this.Hide();
        }

        private void addVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddVehicles av = new AddVehicles();
            av.Show();
            this.Hide();
        }
    }
}
