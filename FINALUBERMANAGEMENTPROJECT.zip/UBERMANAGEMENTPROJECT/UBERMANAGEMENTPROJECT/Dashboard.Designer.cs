﻿namespace UBERMANAGEMENTPROJECT
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.btnuserlogin = new System.Windows.Forms.Button();
            this.btnadminlogin = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnuserlogin
            // 
            this.btnuserlogin.BackColor = System.Drawing.Color.Transparent;
            this.btnuserlogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnuserlogin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnuserlogin.Font = new System.Drawing.Font("Minion Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnuserlogin.ForeColor = System.Drawing.Color.White;
            this.btnuserlogin.Location = new System.Drawing.Point(203, 154);
            this.btnuserlogin.Name = "btnuserlogin";
            this.btnuserlogin.Size = new System.Drawing.Size(86, 54);
            this.btnuserlogin.TabIndex = 0;
            this.btnuserlogin.Text = "USER LOGIN";
            this.btnuserlogin.UseVisualStyleBackColor = false;
            this.btnuserlogin.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnadminlogin
            // 
            this.btnadminlogin.BackColor = System.Drawing.Color.Transparent;
            this.btnadminlogin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnadminlogin.Font = new System.Drawing.Font("Minion Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadminlogin.ForeColor = System.Drawing.Color.White;
            this.btnadminlogin.Location = new System.Drawing.Point(453, 154);
            this.btnadminlogin.Name = "btnadminlogin";
            this.btnadminlogin.Size = new System.Drawing.Size(96, 54);
            this.btnadminlogin.TabIndex = 1;
            this.btnadminlogin.Text = "ADMIN LOGIN";
            this.btnadminlogin.UseVisualStyleBackColor = false;
            this.btnadminlogin.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnexit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnexit.Font = new System.Drawing.Font("Minion Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.ForeColor = System.Drawing.Color.White;
            this.btnexit.Location = new System.Drawing.Point(339, 305);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(86, 54);
            this.btnexit.TabIndex = 2;
            this.btnexit.Text = "EXIT";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnadminlogin);
            this.Controls.Add(this.btnuserlogin);
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnuserlogin;
        private System.Windows.Forms.Button btnadminlogin;
        private System.Windows.Forms.Button btnexit;
    }
}