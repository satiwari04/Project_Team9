﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace UBERMANAGEMENTPROJECT
{
    public partial class Users : Form
    {
        SqlConnection conn;
        public Users()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        public static string SetValueforUsername { get; private set; }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Dashboard db = new Dashboard();
            db.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Username, Password;
            Username = txtusername.Text;
            Password = txtpassword.Text;
            SetValueforUsername = txtusername.Text;

            try
            {
                conn.Open();
                String sql = "select * from USERS where Username=@name and Password=@pass";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlParameter parameter = new SqlParameter("@name", Username);
                SqlParameter parameter1 = new SqlParameter("@pass", Password);
                cmd.Parameters.Add(parameter);
                cmd.Parameters.Add(parameter1);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                        User_login user = new User_login();
                        user.Username = reader[0].ToString();
                        user.Password = reader[1].ToString();
                       // MessageBox.Show("Login Successful");
                        UserPage up = new UserPage();
                        up.Show();
                        this.Hide();
                }
                else
                {
                    MessageBox.Show("Sorry Login not Successful");
                    txtusername.Text = "";
                    txtpassword.Text = "";

                }
                conn.Close();
            }
            catch(Exception ee)
            {
                MessageBox.Show("" + ee.Message);
            }
        }

        private void lblregister_Click(object sender, EventArgs e)
        {
            RegisterPage registerPage = new RegisterPage();
            registerPage.Show();
            this.Hide();
        }

        private void Users_Load(object sender, EventArgs e)
        {

        }
    }
}
