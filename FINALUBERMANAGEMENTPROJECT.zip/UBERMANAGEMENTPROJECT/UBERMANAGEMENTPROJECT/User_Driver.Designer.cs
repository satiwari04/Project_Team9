﻿namespace UBERMANAGEMENTPROJECT
{
    partial class lbldnm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblusernm = new System.Windows.Forms.Label();
            this.lblviewunm = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbldriver = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblusernm
            // 
            this.lblusernm.AutoSize = true;
            this.lblusernm.Location = new System.Drawing.Point(41, 52);
            this.lblusernm.Name = "lblusernm";
            this.lblusernm.Size = new System.Drawing.Size(57, 13);
            this.lblusernm.TabIndex = 0;
            this.lblusernm.Text = "UserName";
            // 
            // lblviewunm
            // 
            this.lblviewunm.AutoSize = true;
            this.lblviewunm.Location = new System.Drawing.Point(163, 52);
            this.lblviewunm.Name = "lblviewunm";
            this.lblviewunm.Size = new System.Drawing.Size(35, 13);
            this.lblviewunm.TabIndex = 1;
            this.lblviewunm.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(549, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "label3";
            // 
            // lbldriver
            // 
            this.lbldriver.AutoSize = true;
            this.lbldriver.Location = new System.Drawing.Point(427, 52);
            this.lbldriver.Name = "lbldriver";
            this.lbldriver.Size = new System.Drawing.Size(66, 13);
            this.lbldriver.TabIndex = 2;
            this.lbldriver.Text = "Driver Name";
            // 
            // lbldnm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbldriver);
            this.Controls.Add(this.lblviewunm);
            this.Controls.Add(this.lblusernm);
            this.Name = "lbldnm";
            this.Text = "User_Driver";
            this.Load += new System.EventHandler(this.lbldnm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblusernm;
        private System.Windows.Forms.Label lblviewunm;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbldriver;
    }
}