﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UBERMANAGEMENTPROJECT
{
    class Driver
    {
        public int DriverId { get; set; }
        public string DriverName { get; set; }
        public long ContactNumber { get; set; }

        public override string ToString()
        {
            string myData = "";
            myData += DriverId.ToString() + "\n";
            myData += DriverName.ToString() + "\n";
            myData += ContactNumber.ToString() + "\n";
            return myData;
        }
    }
}
